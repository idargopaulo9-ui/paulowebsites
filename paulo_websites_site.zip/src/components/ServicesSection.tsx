import { motion } from 'motion/react';
import { ArrowUpRight, Check, MessageCircle } from 'lucide-react';
import { SERVICES, buildWhatsAppUrl } from '../data/portfolioData';

export function ServicesSection() {
  return (
    <section
      id="servicos"
      className="border-b border-white/10 bg-[#05070B] py-16 sm:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div className="max-w-2xl">
            <p className="text-xs font-medium tracking-wide text-blue-300">
              Soluções sob medida para crescer online
            </p>
            <h2 className="mt-2 font-display text-3xl font-bold tracking-tight text-white sm:text-4xl [text-wrap:balance]">
              Serviços pensados para gerar clientes reais
            </h2>
          </div>
          <p className="max-w-md text-sm leading-relaxed text-slate-300 sm:text-base">
            Do primeiro site institucional ao aplicativo completo ou manutenção contínua,
            cada entrega une visual profissional, velocidade e praticidade.
          </p>
        </div>

        {/* Asymmetric Bento Grid */}
        <div className="mt-12 grid grid-cols-1 gap-6 lg:grid-cols-12">
          {SERVICES.map((service, index) => {
            const isFeatured = Boolean(service.featured);
            return (
              <motion.article
                key={service.id}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{
                  duration: 0.4,
                  delay: index * 0.06,
                  ease: [0.16, 1, 0.3, 1],
                }}
                className={`metallic-surface flex flex-col justify-between rounded-2xl p-6 sm:p-8 ${
                  isFeatured ? 'lg:col-span-12 xl:col-span-7' : 'lg:col-span-6 xl:col-span-5'
                } ${service.id === 'manutencao' ? 'xl:col-span-12' : ''}`}
              >
                <div>
                  <div className="flex flex-wrap items-baseline justify-between gap-3 border-b border-white/10 pb-4">
                    <span className="font-mono text-xs tabular-nums text-blue-300">
                      {service.number}. Serviço
                    </span>
                    <span className="text-xs text-slate-300">{service.subtitle}</span>
                  </div>

                  <h3 className="mt-5 font-display text-2xl font-semibold tracking-tight text-white">
                    {service.title}
                  </h3>

                  <p className="mt-3 text-sm leading-relaxed text-slate-300 sm:text-base">
                    {service.description}
                  </p>

                  <ul className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-2">
                    {service.deliverables.map((item) => (
                      <li
                        key={item}
                        className="flex items-start gap-2.5 text-sm text-slate-200"
                      >
                        <Check
                          className="mt-0.5 h-4 w-4 shrink-0 text-blue-400"
                          aria-hidden="true"
                        />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-8 flex items-center justify-between border-t border-white/10 pt-5">
                  <a
                    href={buildWhatsAppUrl(
                      `Olá Paulo! Tenho interesse no serviço: ${service.title}. Gostaria de solicitar um orçamento.`
                    )}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex min-h-[40px] items-center gap-2 text-sm font-semibold text-white transition-colors duration-150 hover:text-blue-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 rounded"
                  >
                    <span>Solicitar orçamento pelo WhatsApp</span>
                    <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                  </a>
                </div>
              </motion.article>
            );
          })}
        </div>

        {/* Section Conversion Strip */}
        <div className="mt-10 flex flex-col items-start justify-between gap-6 rounded-2xl border border-white/15 bg-[#0A1120] p-6 sm:flex-row sm:items-center sm:p-8">
          <div>
            <h3 className="font-display text-xl font-semibold text-white">
              Não sabe qual opção ideal para o seu momento?
            </h3>
            <p className="mt-1 text-sm text-slate-300">
              Explique o seu negócio em poucos minutos e receba uma recomendação clara e
              acessível sem compromisso.
            </p>
          </div>
          <a
            href={buildWhatsAppUrl()}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex min-h-[44px] shrink-0 items-center gap-2 rounded-lg border border-blue-300/35 bg-[#1E3A8A] px-5 py-2.5 text-sm font-semibold text-white whitespace-nowrap shadow-[inset_0_1px_0_rgba(255,255,255,0.2)] transition-colors duration-150 hover:bg-[#2563EB] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
          >
            <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
            <span>Solicite seu orçamento pelo WhatsApp</span>
          </a>
        </div>
      </div>
    </section>
  );
}
