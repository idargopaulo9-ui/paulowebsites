import { CONTACT_INFO, buildWhatsAppUrl } from '../data/portfolioData';

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="bg-[#05070B] py-12">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-8 border-b border-white/10 pb-8 md:flex-row md:items-center">
          <div>
            <a
              href="#inicio"
              className="font-display text-lg font-semibold tracking-tight text-white"
            >
              {CONTACT_INFO.brandName}
            </a>
            <p className="mt-1.5 text-xs text-slate-300 sm:text-sm">
              Criação de sites modernos, aplicativos e manutenção ·{' '}
              {CONTACT_INFO.region}
            </p>
          </div>

          <nav
            aria-label="Links do rodapé"
            className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-slate-300"
          >
            <a href="#servicos" className="hover:text-white transition-colors">
              Serviços
            </a>
            <a href="#portfolio" className="hover:text-white transition-colors">
              Portfólio
            </a>
            <a href="#sobre" className="hover:text-white transition-colors">
              Sobre
            </a>
            <a href="#depoimentos" className="hover:text-white transition-colors">
              Depoimentos
            </a>
            <a href="#contato" className="hover:text-white transition-colors">
              Contato
            </a>
          </nav>
        </div>

        <div className="mt-8 flex flex-col justify-between gap-4 text-xs text-slate-400 sm:flex-row sm:items-center">
          <p>
            © {year} {CONTACT_INFO.brandName}. Todos os direitos reservados.
          </p>
          <div className="flex flex-wrap items-center gap-4">
            <a
              href={buildWhatsAppUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="font-mono tabular-nums text-slate-300 hover:text-white transition-colors"
            >
              WhatsApp: {CONTACT_INFO.whatsappDisplay}
            </a>
            <span aria-hidden="true">·</span>
            <a
              href={CONTACT_INFO.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-slate-300 hover:text-white transition-colors"
            >
              Instagram: {CONTACT_INFO.instagramHandle}
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
