import { motion } from 'motion/react';
import { TESTIMONIALS } from '../data/portfolioData';

export function TestimonialsSection() {
  return (
    <section
      id="depoimentos"
      className="border-b border-white/10 bg-[#070B14] py-16 sm:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
          <div className="max-w-2xl">
            <p className="text-xs font-medium tracking-wide text-blue-300">
              Prova Social · Empresas Atendidas
            </p>
            <h2 className="mt-2 font-display text-3xl font-bold tracking-tight text-white sm:text-4xl [text-wrap:balance]">
              O que clientes dizem após colocar o projeto no ar
            </h2>
          </div>
          <p className="text-sm text-slate-300">
            Relatos reais sobre agilidade, qualidade e retorno comercial.
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-6 md:grid-cols-3">
          {TESTIMONIALS.map((item, idx) => (
            <motion.blockquote
              key={item.id}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{
                duration: 0.4,
                delay: idx * 0.06,
                ease: [0.16, 1, 0.3, 1],
              }}
              className="metallic-surface flex flex-col justify-between rounded-2xl p-6 sm:p-7"
            >
              <div>
                <p className="text-xs font-medium text-blue-300">{item.outcome}</p>
                <p className="mt-4 text-sm leading-relaxed text-slate-200 sm:text-base">
                  “{item.quote}”
                </p>
              </div>

              <footer className="mt-6 border-t border-white/10 pt-4">
                <p className="font-display text-base font-semibold text-white">
                  {item.clientName}
                </p>
                <p className="mt-0.5 text-xs text-slate-300">
                  {item.role} · {item.company}
                </p>
              </footer>
            </motion.blockquote>
          ))}
        </div>
      </div>
    </section>
  );
}
