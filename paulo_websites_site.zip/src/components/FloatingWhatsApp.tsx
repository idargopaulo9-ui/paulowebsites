import { MessageCircle } from 'lucide-react';
import { buildWhatsAppUrl } from '../data/portfolioData';

export function FloatingWhatsApp() {
  return (
    <a
      href={buildWhatsAppUrl()}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Solicitar orçamento pelo WhatsApp"
      className="fixed right-4 bottom-4 z-40 inline-flex h-11 items-center gap-2 rounded-xl border border-blue-300/40 bg-[#1E3A8A] px-3.5 text-xs font-semibold text-white shadow-lg shadow-black/50 transition-transform duration-150 hover:-translate-y-0.5 hover:bg-[#2563EB] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 sm:right-6 sm:bottom-6 sm:h-12 sm:px-4 sm:text-sm"
    >
      <MessageCircle className="h-4 w-4 shrink-0 sm:h-5 sm:w-5" aria-hidden="true" />
      <span className="whitespace-nowrap">WhatsApp</span>
    </a>
  );
}
