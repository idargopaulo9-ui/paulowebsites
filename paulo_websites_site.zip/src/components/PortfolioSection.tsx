import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ArrowUpRight, Check, MessageCircle, X } from 'lucide-react';
import {
  PROJECTS,
  ProjectCategory,
  ProjectItem,
  buildWhatsAppUrl,
} from '../data/portfolioData';
import { ResilientImage } from './ResilientImage';

const FILTER_TABS: { id: ProjectCategory; label: string }[] = [
  { id: 'todos', label: 'Todos os Projetos' },
  { id: 'sites', label: 'Sites Profissionais' },
  { id: 'aplicativos', label: 'Aplicativos' },
];

export function PortfolioSection() {
  const [activeFilter, setActiveFilter] = useState<ProjectCategory>('todos');
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);

  const filteredProjects =
    activeFilter === 'todos'
      ? PROJECTS
      : PROJECTS.filter((project) => project.category === activeFilter);

  useEffect(() => {
    if (!selectedProject) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setSelectedProject(null);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedProject]);

  return (
    <section
      id="portfolio"
      className="border-b border-white/10 bg-[#070B14] py-16 sm:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
          <div className="max-w-2xl">
            <p className="text-xs font-medium tracking-wide text-blue-300">
              Portfólio Selecionado · Resultados Reais
            </p>
            <h2 className="mt-2 font-display text-3xl font-bold tracking-tight text-white sm:text-4xl [text-wrap:balance]">
              Projetos desenvolvidos para destacar marcas e acelerar vendas
            </h2>
          </div>

          {/* Interactive Filter Controls */}
          <div
            role="tablist"
            aria-label="Filtrar projetos por categoria"
            className="inline-flex w-fit flex-wrap items-center gap-1 rounded-lg border border-white/15 bg-[#05070B] p-1"
          >
            {FILTER_TABS.map((tab) => {
              const isActive = activeFilter === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  role="tab"
                  aria-selected={isActive}
                  onClick={() => setActiveFilter(tab.id)}
                  className={`min-h-[38px] rounded-md px-3.5 py-1.5 text-xs font-medium whitespace-nowrap shrink-0 transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 ${
                    isActive
                      ? 'bg-[#1E3A8A] text-white shadow-sm'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Projects Grid */}
        <div className="mt-12 grid grid-cols-1 gap-6 lg:grid-cols-12">
          {filteredProjects.map((project, index) => {
            const isHeroProject =
              activeFilter === 'todos' && index === 0;
            return (
              <motion.article
                key={project.id}
                layout
                initial={{ opacity: 0, y: 14 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.15 }}
                transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
                className={`metallic-surface group flex flex-col overflow-hidden rounded-2xl ${
                  isHeroProject
                    ? 'lg:col-span-12 lg:grid lg:grid-cols-12'
                    : 'lg:col-span-6'
                }`}
              >
                <div
                  className={`relative overflow-hidden ${
                    isHeroProject ? 'lg:col-span-7' : ''
                  }`}
                >
                  <ResilientImage
                    src={project.image}
                    alt={project.imageAlt}
                    fallbackTitle={project.title}
                    className={`w-full transition-transform duration-300 group-hover:scale-[1.02] ${
                      isHeroProject ? 'aspect-[4/3] lg:h-full lg:aspect-auto' : 'aspect-[4/3]'
                    }`}
                  />
                </div>

                <div
                  className={`flex flex-1 flex-col justify-between p-6 sm:p-8 ${
                    isHeroProject ? 'lg:col-span-5' : ''
                  }`}
                >
                  <div>
                    {/* Clean unboxed metadata */}
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-300">
                      <span>{project.categoryLabel}</span>
                      <span aria-hidden="true">·</span>
                      <span>{project.client}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">{project.year}</span>
                    </div>

                    <h3 className="mt-3 font-display text-2xl font-semibold tracking-tight text-white">
                      {project.title}
                    </h3>

                    <p className="mt-3 text-sm leading-relaxed text-slate-300">
                      {project.summary}
                    </p>

                    <div className="mt-6 border-t border-white/10 pt-4">
                      <p className="font-display text-2xl font-bold tabular-nums text-white">
                        {project.metricValue}
                      </p>
                      <p className="mt-0.5 text-xs text-slate-300">
                        {project.metricLabel}
                      </p>
                    </div>
                  </div>

                  <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-t border-white/10 pt-5">
                    <button
                      type="button"
                      onClick={() => setSelectedProject(project)}
                      className="inline-flex min-h-[40px] items-center gap-1.5 text-sm font-semibold text-white transition-colors duration-150 hover:text-blue-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 rounded"
                    >
                      <span>Ver detalhes do projeto</span>
                      <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                    </button>

                    <a
                      href={buildWhatsAppUrl(
                        `Olá Paulo! Vi o projeto "${project.title}" no seu portfólio e quero algo nesse padrão para minha empresa.`
                      )}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs font-medium text-blue-300 hover:text-white transition-colors whitespace-nowrap"
                    >
                      Quero um projeto assim
                    </a>
                  </div>
                </div>
              </motion.article>
            );
          })}
        </div>
      </div>

      {/* Project Lightbox / Detail Modal */}
      <AnimatePresence>
        {selectedProject && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            onClick={() => setSelectedProject(null)}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
            role="dialog"
            aria-modal="true"
            aria-labelledby="project-modal-title"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.97, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.97, y: 8 }}
              transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="metallic-surface relative max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-2xl p-6 sm:p-8"
            >
              <button
                type="button"
                onClick={() => setSelectedProject(null)}
                aria-label="Fechar detalhes do projeto"
                className="absolute top-4 right-4 inline-flex h-10 w-10 items-center justify-center rounded-lg border border-white/15 bg-[#05070B] text-slate-200 transition-colors hover:border-white/30 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
              >
                <X className="h-5 w-5" aria-hidden="true" />
              </button>

              <div className="pr-12">
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-300">
                  <span>{selectedProject.categoryLabel}</span>
                  <span aria-hidden="true">·</span>
                  <span>{selectedProject.client}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">{selectedProject.year}</span>
                </div>
                <h3
                  id="project-modal-title"
                  className="mt-2 font-display text-2xl font-bold text-white sm:text-3xl"
                >
                  {selectedProject.title}
                </h3>
              </div>

              <div className="mt-6 overflow-hidden rounded-xl border border-white/10">
                <ResilientImage
                  src={selectedProject.image}
                  alt={selectedProject.imageAlt}
                  fallbackTitle={selectedProject.title}
                  className="aspect-[4/3] w-full"
                />
              </div>

              <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2">
                <div>
                  <h4 className="font-display text-sm font-semibold text-white">
                    O Desafio
                  </h4>
                  <p className="mt-1.5 text-sm leading-relaxed text-slate-300">
                    {selectedProject.challenge}
                  </p>
                </div>
                <div>
                  <h4 className="font-display text-sm font-semibold text-white">
                    A Solução Aplicada
                  </h4>
                  <p className="mt-1.5 text-sm leading-relaxed text-slate-300">
                    {selectedProject.solution}
                  </p>
                </div>
              </div>

              <div className="mt-6 border-t border-white/10 pt-6">
                <h4 className="font-display text-sm font-semibold text-white">
                  O que foi entregue
                </h4>
                <ul className="mt-3 grid grid-cols-1 gap-2.5 sm:grid-cols-3">
                  {selectedProject.deliverables.map((item) => (
                    <li
                      key={item}
                      className="flex items-start gap-2 text-xs leading-relaxed text-slate-200 sm:text-sm"
                    >
                      <Check
                        className="mt-0.5 h-4 w-4 shrink-0 text-blue-400"
                        aria-hidden="true"
                      />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mt-8 flex flex-col items-start justify-between gap-4 border-t border-white/10 pt-6 sm:flex-row sm:items-center">
                <div>
                  <p className="font-display text-2xl font-bold tabular-nums text-white">
                    {selectedProject.metricValue}
                  </p>
                  <p className="text-xs text-slate-300">{selectedProject.metricLabel}</p>
                </div>
                <a
                  href={buildWhatsAppUrl(
                    `Olá Paulo! Vi o estudo de caso "${selectedProject.title}" e gostaria de solicitar um orçamento para o meu negócio.`
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-[44px] items-center gap-2 rounded-lg border border-blue-300/35 bg-[#1E3A8A] px-5 py-2.5 text-sm font-semibold text-white whitespace-nowrap transition-colors hover:bg-[#2563EB] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
                >
                  <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
                  <span>Solicite seu orçamento pelo WhatsApp</span>
                </a>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
