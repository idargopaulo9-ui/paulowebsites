import { FormEvent, useState } from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, Instagram, MapPin, MessageCircle, Send } from 'lucide-react';
import { CONTACT_INFO, buildWhatsAppUrl } from '../data/portfolioData';

type ProjectType =
  | 'Criação de Site Profissional'
  | 'Desenvolvimento de Aplicativo'
  | 'Manutenção de Site'
  | 'Outro projeto digital';

interface FormErrors {
  name?: string;
  phone?: string;
  message?: string;
}

export function ContactSection() {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [company, setCompany] = useState('');
  const [projectType, setProjectType] = useState<ProjectType>(
    'Criação de Site Profissional'
  );
  const [message, setMessage] = useState('');
  const [errors, setErrors] = useState<FormErrors>({});
  const [submittedMessage, setSubmittedMessage] = useState<string | null>(null);

  const validate = (): boolean => {
    const nextErrors: FormErrors = {};
    if (name.trim().length < 2) {
      nextErrors.name = 'Informe seu nome para iniciarmos o atendimento.';
    }
    const digits = phone.replace(/\D/g, '');
    if (digits.length < 10) {
      nextErrors.phone = 'Informe um WhatsApp válido com DDD (ex: 11 99722-8901).';
    }
    if (message.trim().length < 10) {
      nextErrors.message = 'Descreva brevemente o objetivo do seu site ou aplicativo.';
    }
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    if (!validate()) return;

    const compiled = [
      `Olá Paulo! Gostaria de solicitar um orçamento pela Paulo_websites.`,
      `Nome: ${name.trim()}`,
      company.trim() ? `Empresa: ${company.trim()}` : null,
      `WhatsApp para retorno: ${phone.trim()}`,
      `Serviço: ${projectType}`,
      `Detalhes do projeto: ${message.trim()}`,
    ]
      .filter(Boolean)
      .join('\n');

    setSubmittedMessage(compiled);
  };

  return (
    <section
      id="contato"
      className="border-b border-white/10 bg-[#05070B] py-16 sm:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-14">
          {/* Left Column: Direct Conversion Pitch + Official Channels */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-between lg:col-span-5"
          >
            <div>
              <p className="text-xs font-medium tracking-wide text-blue-300">
                Comece Seu Projeto Hoje
              </p>
              <h2 className="mt-2 font-display text-3xl font-bold tracking-tight text-white sm:text-4xl [text-wrap:balance]">
                Solicite seu orçamento pelo WhatsApp sem burocracia
              </h2>
              <p className="mt-4 text-sm leading-relaxed text-slate-300 sm:text-base">
                Preencha o briefing ao lado ou chame diretamente pelo WhatsApp. Você
                conversa direto comigo, recebe uma proposta clara e coloca seu projeto no
                ar com agilidade.
              </p>

              {/* Direct Channel Links */}
              <div className="mt-8 divide-y divide-white/10 border-t border-b border-white/10">
                <a
                  href={buildWhatsAppUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex min-h-[68px] items-center justify-between gap-4 py-4 transition-colors hover:text-blue-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 rounded"
                >
                  <div className="flex items-center gap-3.5">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-white/15 bg-[#0A1120] text-blue-300">
                      <MessageCircle className="h-4 w-4" aria-hidden="true" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-300">WhatsApp Direto</p>
                      <p className="font-mono text-sm font-medium tabular-nums text-white group-hover:text-blue-300">
                        {CONTACT_INFO.whatsappDisplay}
                      </p>
                    </div>
                  </div>
                  <span className="text-xs font-medium text-blue-300 whitespace-nowrap">
                    Iniciar conversa
                  </span>
                </a>

                <a
                  href={CONTACT_INFO.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex min-h-[68px] items-center justify-between gap-4 py-4 transition-colors hover:text-blue-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 rounded"
                >
                  <div className="flex items-center gap-3.5">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-white/15 bg-[#0A1120] text-slate-200">
                      <Instagram className="h-4 w-4" aria-hidden="true" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-300">Instagram</p>
                      <p className="text-sm font-medium text-white group-hover:text-blue-300">
                        {CONTACT_INFO.instagramHandle}
                      </p>
                    </div>
                  </div>
                  <span className="text-xs font-medium text-slate-300 whitespace-nowrap group-hover:text-white">
                    Ver perfil
                  </span>
                </a>

                <div className="flex min-h-[64px] items-center gap-3.5 py-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-white/15 bg-[#0A1120] text-slate-200">
                    <MapPin className="h-4 w-4" aria-hidden="true" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-300">Abrangência</p>
                    <p className="text-sm font-medium text-white">
                      {CONTACT_INFO.region}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-8">
              <a
                href={buildWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[48px] w-full items-center justify-center gap-2.5 rounded-lg border border-blue-300/35 bg-[#1E3A8A] px-6 py-3 text-sm font-semibold text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.22)] transition-colors duration-150 hover:bg-[#2563EB] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 sm:w-auto"
              >
                <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>Solicite seu orçamento pelo WhatsApp</span>
              </a>
            </div>
          </motion.div>

          {/* Right Column: Validated Lead Capture Form */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.45, delay: 0.06, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7"
          >
            <div className="metallic-surface rounded-2xl p-6 sm:p-8">
              {submittedMessage ? (
                <div className="space-y-6 py-4">
                  <div className="flex items-start gap-3">
                    <CheckCircle2
                      className="mt-0.5 h-6 w-6 shrink-0 text-blue-400"
                      aria-hidden="true"
                    />
                    <div>
                      <h3 className="font-display text-2xl font-semibold text-white">
                        Solicitação estruturada com sucesso
                      </h3>
                      <p className="mt-1 text-sm text-slate-300">
                        Clique no botão abaixo para abrir o WhatsApp com os detalhes do
                        seu projeto já preenchidos e receber seu orçamento hoje.
                      </p>
                    </div>
                  </div>

                  <div className="rounded-xl border border-white/10 bg-[#05070B] p-4 text-xs leading-relaxed text-slate-200 whitespace-pre-line sm:text-sm">
                    {submittedMessage}
                  </div>

                  <div className="flex flex-wrap items-center gap-4">
                    <a
                      href={buildWhatsAppUrl(submittedMessage)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex min-h-[48px] items-center gap-2 rounded-lg border border-blue-300/35 bg-[#1E3A8A] px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-[#2563EB] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
                    >
                      <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
                      <span>Enviar orçamento no WhatsApp agora</span>
                    </a>
                    <button
                      type="button"
                      onClick={() => setSubmittedMessage(null)}
                      className="inline-flex min-h-[44px] items-center rounded-lg border border-white/15 px-4 py-2 text-sm font-medium text-slate-200 hover:border-white/30 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
                    >
                      Editar dados
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} noValidate className="space-y-5">
                  <div>
                    <h3 className="font-display text-xl font-semibold text-white">
                      Conte sobre o seu projeto
                    </h3>
                    <p className="mt-1 text-xs text-slate-300 sm:text-sm">
                      Preencha os campos abaixo para montar seu pedido de orçamento em
                      segundos.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                    <div>
                      <label
                        htmlFor="contact-name"
                        className="block text-xs font-medium text-slate-200"
                      >
                        Seu nome *
                      </label>
                      <input
                        id="contact-name"
                        type="text"
                        value={name}
                        onChange={(e) => {
                          setName(e.target.value);
                          if (errors.name) setErrors({ ...errors, name: undefined });
                        }}
                        placeholder="Ex: Marcos Oliveira"
                        className="mt-1.5 w-full min-h-[44px] rounded-lg border border-white/15 bg-[#05070B] px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-blue-400 focus:outline-none focus:ring-1 focus:ring-blue-400"
                      />
                      {errors.name && (
                        <p className="mt-1.5 text-xs text-red-400" role="alert">
                          {errors.name}
                        </p>
                      )}
                    </div>

                    <div>
                      <label
                        htmlFor="contact-phone"
                        className="block text-xs font-medium text-slate-200"
                      >
                        Seu WhatsApp *
                      </label>
                      <input
                        id="contact-phone"
                        type="tel"
                        value={phone}
                        onChange={(e) => {
                          setPhone(e.target.value);
                          if (errors.phone) setErrors({ ...errors, phone: undefined });
                        }}
                        placeholder="(11) 99999-9999"
                        className="mt-1.5 w-full min-h-[44px] rounded-lg border border-white/15 bg-[#05070B] px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-blue-400 focus:outline-none focus:ring-1 focus:ring-blue-400"
                      />
                      {errors.phone && (
                        <p className="mt-1.5 text-xs text-red-400" role="alert">
                          {errors.phone}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                    <div>
                      <label
                        htmlFor="contact-company"
                        className="block text-xs font-medium text-slate-200"
                      >
                        Empresa ou segmento
                      </label>
                      <input
                        id="contact-company"
                        type="text"
                        value={company}
                        onChange={(e) => setCompany(e.target.value)}
                        placeholder="Ex: Clínica, Loja, Escritório..."
                        className="mt-1.5 w-full min-h-[44px] rounded-lg border border-white/15 bg-[#05070B] px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-blue-400 focus:outline-none focus:ring-1 focus:ring-blue-400"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="contact-service"
                        className="block text-xs font-medium text-slate-200"
                      >
                        O que você precisa?
                      </label>
                      <select
                        id="contact-service"
                        value={projectType}
                        onChange={(e) => setProjectType(e.target.value as ProjectType)}
                        className="mt-1.5 w-full min-h-[44px] rounded-lg border border-white/15 bg-[#05070B] px-3.5 py-2.5 text-sm text-white focus:border-blue-400 focus:outline-none focus:ring-1 focus:ring-blue-400"
                      >
                        <option value="Criação de Site Profissional">
                          Criação de Site Profissional
                        </option>
                        <option value="Desenvolvimento de Aplicativo">
                          Desenvolvimento de Aplicativo
                        </option>
                        <option value="Manutenção de Site">Manutenção de Site</option>
                        <option value="Outro projeto digital">
                          Outro projeto digital
                        </option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="contact-message"
                      className="block text-xs font-medium text-slate-200"
                    >
                      Sobre o seu projeto *
                    </label>
                    <textarea
                      id="contact-message"
                      rows={4}
                      value={message}
                      onChange={(e) => {
                        setMessage(e.target.value);
                        if (errors.message) setErrors({ ...errors, message: undefined });
                      }}
                      placeholder="Conte o que sua empresa faz e qual resultado espera com o novo site ou aplicativo..."
                      className="mt-1.5 w-full rounded-lg border border-white/15 bg-[#05070B] px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-blue-400 focus:outline-none focus:ring-1 focus:ring-blue-400"
                    />
                    {errors.message && (
                      <p className="mt-1.5 text-xs text-red-400" role="alert">
                        {errors.message}
                      </p>
                    )}
                  </div>

                  <button
                    type="submit"
                    className="inline-flex min-h-[48px] w-full items-center justify-center gap-2 rounded-lg border border-blue-300/35 bg-[#1E3A8A] px-6 py-3 text-sm font-semibold text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.22)] transition-colors duration-150 hover:bg-[#2563EB] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
                  >
                    <Send className="h-4 w-4 shrink-0" aria-hidden="true" />
                    <span>Solicitar orçamento pelo WhatsApp</span>
                  </button>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
