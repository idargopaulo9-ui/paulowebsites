import { motion } from 'motion/react';
import { MessageCircle } from 'lucide-react';
import { ABOUT_IMAGE, DIFFERENTIALS, buildWhatsAppUrl } from '../data/portfolioData';
import { ResilientImage } from './ResilientImage';

export function AboutSection() {
  return (
    <section
      id="sobre"
      className="border-b border-white/10 bg-[#05070B] py-16 sm:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 items-stretch gap-10 lg:grid-cols-12 lg:gap-12">
          {/* Left Column: Studio Portrait / Workspace */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5"
          >
            <div className="metallic-surface relative h-full overflow-hidden rounded-2xl p-2">
              <ResilientImage
                src={ABOUT_IMAGE}
                alt="Paulo desenvolvendo interfaces digitais em seu estúdio minimalista em tons de azul marinho e preto"
                fallbackTitle="Paulo · Desenvolvedor Web & Apps"
                className="aspect-[4/3] h-full w-full rounded-xl lg:aspect-auto"
              />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-x-2 bottom-2 h-24 rounded-b-xl bg-gradient-to-t from-[#05070B]/85 via-[#05070B]/30 to-transparent"
              />
              <div className="pointer-events-none absolute inset-x-6 bottom-5 flex items-center justify-between text-xs text-slate-200">
                <span className="font-medium">Paulo · Paulo_websites</span>
                <span className="text-slate-300">Atendimento direto</span>
              </div>
            </div>
          </motion.div>

          {/* Right Column: Bio + 5 Competitive Differentials */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.45, delay: 0.06, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-between lg:col-span-7"
          >
            <div>
              <p className="text-xs font-medium tracking-wide text-blue-300">
                Quem está por trás dos projetos
              </p>
              <h2 className="mt-2 font-display text-3xl font-bold tracking-tight text-white sm:text-4xl [text-wrap:balance]">
                Design, qualidade técnica e atendimento direto ao ponto
              </h2>

              <p className="mt-5 text-base leading-relaxed text-slate-200 sm:text-lg">
                Sou Paulo, desenvolvedor especializado na criação de sites e aplicativos
                modernos, com foco em design, qualidade, praticidade e excelente
                custo-benefício.
              </p>
              <p className="mt-3 text-sm leading-relaxed text-slate-300 sm:text-base">
                Meu compromisso é tirar sua empresa da invisibilidade ou de páginas
                amadoras, entregando uma estrutura digital que passa confiança imediata e
                transforma visitas em conversas reais no seu WhatsApp.
              </p>

              {/* 5 Differentials with clean hairline dividers */}
              <div className="mt-8 divide-y divide-white/10 border-t border-b border-white/10">
                {DIFFERENTIALS.map((item) => (
                  <div
                    key={item.number}
                    className="grid grid-cols-1 gap-1.5 py-4 sm:grid-cols-12 sm:items-baseline sm:gap-4"
                  >
                    <div className="flex items-baseline gap-3 sm:col-span-5">
                      <span className="font-mono text-xs tabular-nums text-blue-300">
                        {item.number}.
                      </span>
                      <h3 className="font-display text-base font-semibold text-white">
                        {item.title}
                      </h3>
                    </div>
                    <p className="text-sm leading-relaxed text-slate-300 sm:col-span-7">
                      {item.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-8">
              <a
                href={buildWhatsAppUrl(
                  'Olá Paulo! Li sobre o seu trabalho e gostaria de conversar sobre o projeto do meu negócio.'
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[46px] items-center gap-2 rounded-lg border border-blue-300/35 bg-[#1E3A8A] px-6 py-3 text-sm font-semibold text-white whitespace-nowrap shadow-[inset_0_1px_0_rgba(255,255,255,0.2)] transition-colors duration-150 hover:bg-[#2563EB] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
              >
                <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>Solicite seu orçamento pelo WhatsApp</span>
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
