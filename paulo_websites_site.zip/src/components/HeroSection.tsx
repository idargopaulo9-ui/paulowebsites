import { motion } from 'motion/react';
import { ArrowDownRight, MessageCircle } from 'lucide-react';
import { HERO_IMAGE, HERO_METRICS, buildWhatsAppUrl } from '../data/portfolioData';
import { ResilientImage } from './ResilientImage';

export function HeroSection() {
  return (
    <section
      id="inicio"
      className="relative overflow-hidden border-b border-white/10 bg-gradient-to-b from-[#081022] via-[#05070B] to-[#05070B]"
    >
      {/* Subtle architectural navy ambient radial glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-40 right-0 h-[480px] w-[640px] rounded-full bg-[#1E3A8A]/20 blur-[140px]"
      />

      <div className="relative mx-auto max-w-6xl px-4 pt-12 pb-14 sm:px-6 sm:pt-16 sm:pb-20 lg:px-8 lg:pt-20">
        {/* 2-Column Hero Split */}
        <div className="grid grid-cols-1 items-stretch gap-10 lg:grid-cols-12 lg:gap-12">
          {/* Left Column: High-conversion typographic hierarchy */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-center lg:col-span-6"
          >
            <p className="text-xs font-medium tracking-wide text-slate-300">
              Criação de Sites &amp; Aplicativos · Atendimento em todo o Brasil
            </p>

            <h1
              className="mt-4 font-display font-bold tracking-tight text-white [text-wrap:balance]"
              style={{ fontSize: 'clamp(2.25rem, 4vw, 3.65rem)', lineHeight: 1.08 }}
            >
              Seu negócio merece mais.{' '}
              <span className="metallic-text">Sua presença digital também.</span>
            </h1>

            <p className="mt-6 max-w-xl text-base leading-relaxed text-slate-300 sm:text-lg">
              Sites modernos, aplicativos sob medida e manutenção ágil para empresas e
              empreendedores que querem transmitir autoridade, atrair clientes todos os dias e
              vender mais — com atendimento direto e excelente custo-benefício.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <a
                href={buildWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[48px] items-center gap-2.5 rounded-lg border border-blue-300/35 bg-[#1E3A8A] px-6 py-3 text-sm font-semibold text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.22)] transition-all duration-150 hover:bg-[#2563EB] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
              >
                <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>Solicite seu orçamento pelo WhatsApp</span>
              </a>

              <a
                href="#portfolio"
                className="inline-flex min-h-[48px] items-center gap-1.5 rounded-lg border border-white/15 bg-white/[0.03] px-5 py-3 text-sm font-medium text-slate-200 whitespace-nowrap transition-colors duration-150 hover:border-white/30 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
              >
                <span>Ver projetos</span>
                <ArrowDownRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </motion.div>

          {/* Right Column: Matching-height visual showcase */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6"
          >
            <div className="metallic-surface relative h-full min-h-[280px] overflow-hidden rounded-2xl p-2 sm:min-h-[360px]">
              <ResilientImage
                src={HERO_IMAGE}
                alt="Estúdio Paulo_websites exibindo interface corporativa moderna em notebook e monitor sobre mesa escura"
                fallbackTitle="Paulo_websites · Projetos Digitais"
                loading="eager"
                className="h-full w-full rounded-xl aspect-video lg:aspect-auto"
              />
              {/* Measured bottom contrast scrim */}
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-x-2 bottom-2 h-24 rounded-b-xl bg-gradient-to-t from-[#05070B]/85 via-[#05070B]/35 to-transparent"
              />
              <div className="pointer-events-none absolute inset-x-6 bottom-5 flex items-center justify-between gap-4 text-xs text-slate-200">
                <span className="font-medium">Design exclusivo · Alta conversão</span>
                <span className="font-mono tabular-nums text-slate-300">Brasil</span>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Full-width 4-column metric / differential strip below the split */}
        <div className="mt-12 grid grid-cols-2 gap-6 border-t border-white/10 pt-8 md:grid-cols-4 md:gap-8">
          {HERO_METRICS.map((item, idx) => (
            <div key={item.value} className="space-y-1">
              <div className="flex items-baseline gap-2">
                <span className="font-mono text-xs tabular-nums text-slate-400">
                  0{idx + 1}.
                </span>
                <p className="font-display text-lg font-semibold text-white sm:text-xl">
                  {item.value}
                </p>
              </div>
              <p className="text-xs leading-relaxed text-slate-300 sm:text-sm">
                {item.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
