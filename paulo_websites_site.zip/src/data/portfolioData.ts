export const CONTACT_INFO = {
  brandName: 'Paulo_websites',
  whatsappDisplay: '+55 11 99722-8901',
  whatsappNumber: '5511997228901',
  instagramHandle: '@paulo_websites',
  instagramUrl: 'https://www.instagram.com/paulo_websites/',
  region: 'Atendimento em todo o Brasil',
} as const;

export function buildWhatsAppUrl(customMessage?: string): string {
  const defaultMessage =
    'Olá Paulo! Vi seu portfólio Paulo_websites e gostaria de solicitar um orçamento para meu projeto.';
  const text = encodeURIComponent(customMessage || defaultMessage);
  return `https://wa.me/${CONTACT_INFO.whatsappNumber}?text=${text}`;
}

export interface ServiceItem {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  description: string;
  deliverables: string[];
  featured?: boolean;
}

export const SERVICES: ServiceItem[] = [
  {
    id: 'sites',
    number: '01',
    title: 'Criação de Sites Modernos e Profissionais',
    subtitle: 'Institucionais · Landing Pages · Lojas Virtuais',
    description:
      'Projetamos sites sob medida para posicionar sua empresa com autoridade e transformar visitantes em pedidos de orçamento no WhatsApp. Estrutura rápida, segura e pronta para ranquear no Google.',
    deliverables: [
      'Layout exclusivo alinhado à identidade da marca',
      'Adaptação completa para celular, tablet e desktop',
      'Botões estratégicos de conversão e SEO técnico inicial',
      'Carregamento ultrarrápido e certificado SSL configurado',
    ],
    featured: true,
  },
  {
    id: 'apps',
    number: '02',
    title: 'Desenvolvimento de Aplicativos',
    subtitle: 'Web Apps · Aplicativos Sob Medida',
    description:
      'Soluções digitais práticas para digitalizar rotinas da sua empresa, criar áreas de clientes, sistemas de agendamento ou plataformas exclusivas com interface intuitiva.',
    deliverables: [
      'Arquitetura escalável e interface de fácil uso',
      'Integração com APIs, pagamentos e WhatsApp',
      'Painéis administrativos objetivos para sua equipe',
    ],
  },
  {
    id: 'manutencao',
    number: '03',
    title: 'Manutenção e Evolução de Sites',
    subtitle: 'Suporte Contínuo · Segurança · Performance',
    description:
      'Seu site já está no ar mas está lento, desatualizado ou dando erros? Assumimos a parte técnica com melhorias contínuas, backups, ajustes visuais e otimização de velocidade.',
    deliverables: [
      'Correção de falhas e atualização de conteúdo',
      'Otimização de velocidade para dispositivos móveis',
      'Atendimento direto e sem burocracia pelo WhatsApp',
    ],
  },
];

export type ProjectCategory = 'todos' | 'sites' | 'aplicativos';

export interface ProjectItem {
  id: string;
  title: string;
  client: string;
  category: Exclude<ProjectCategory, 'todos'>;
  categoryLabel: string;
  year: string;
  image: string;
  imageAlt: string;
  metricValue: string;
  metricLabel: string;
  summary: string;
  challenge: string;
  solution: string;
  deliverables: string[];
}

export const PROJECTS: ProjectItem[] = [
  {
    id: 'architectura-group',
    title: 'Portal Corporativo & Captação B2B',
    client: 'Architectura Group',
    category: 'sites',
    categoryLabel: 'Site Institucional',
    year: '2026',
    image: '/src/assets/images/project_corporate_web_1795037708011.jpg',
    imageAlt: 'Monitor em escritório exibindo o site institucional da Architectura Group em azul marinho e branco',
    metricValue: '+145%',
    metricLabel: 'Solicitações de orçamento em 90 dias',
    summary:
      'Reestruturação completa da presença digital de um escritório corporativo com foco em apresentação de portfólio e qualificação imediata de leads.',
    challenge:
      'O site antigo era lento no celular, não transmitia o padrão dos projetos entregues e fazia clientes desistirem antes do contato.',
    solution:
      'Desenvolvemos uma vitrine digital de alto contraste com navegação direta, galeria leve em alta definição e integração imediata com WhatsApp comercial.',
    deliverables: [
      'Design personalizado em azul marinho e branco',
      'Galeria otimizada com carregamento instantâneo',
      'Formulário inteligente conectado ao WhatsApp',
    ],
  },
  {
    id: 'fintech-gestao-app',
    title: 'Aplicativo de Gestão e Fluxo Financeiro',
    client: 'Vértice Consultoria Empresarial',
    category: 'aplicativos',
    categoryLabel: 'Aplicativo Web & Mobile',
    year: '2026',
    image: '/src/assets/images/project_mobile_app_1795037708707.jpg',
    imageAlt: 'Smartphone sobre superfície metálica escovada exibindo dashboard financeiro em azul marinho',
    metricValue: '-68%',
    metricLabel: 'Tempo gasto em relatórios semanais',
    summary:
      'Aplicativo mobile-first para empresários acompanharem receitas, metas mensais e aprovações em tempo real direto do celular.',
    challenge:
      'Diretores dependiam de planilhas pesadas e demoravam dias para consolidar indicadores comerciais entre equipes.',
    solution:
      'Construímos uma interface limpa com leitura imediata de indicadores, filtros ágeis e alertas organizados em tela única.',
    deliverables: [
      'Painel executivo responsivo para smartphone',
      'Gráficos de desempenho em tempo real',
      'Fluxo rápido de lançamentos e relatórios',
    ],
  },
  {
    id: 'velocity-store',
    title: 'Vitrine E-commerce de Alta Conversão',
    client: 'Velocity Essentials',
    category: 'sites',
    categoryLabel: 'Loja Virtual & Catálogo',
    year: '2025',
    image: '/src/assets/images/project_ecommerce_brand_1795037708521.jpg',
    imageAlt: 'Notebook sobre pedra escura exibindo loja virtual Velocity em tons de azul marinho e preto',
    metricValue: '3,2x',
    metricLabel: 'Aumento na taxa de conclusão de pedidos',
    summary:
      'Experiência de compra minimalista para marca de acessórios premium, eliminando etapas desnecessárias entre o catálogo e o fechamento.',
    challenge:
      'A loja anterior tinha excesso de banners que distraíam o comprador e um checkout confuso no mobile.',
    solution:
      'Aplicamos hierarquia visual clara, fichas de produto objetivas e botão de compra e atendimento rápido sempre acessível.',
    deliverables: [
      'Vitrine limpa com foco nos produtos',
      'Checkout simplificado para celular',
      'Suporte técnico contínuo e manutenção mensal',
    ],
  },
];

export interface DifferentialItem {
  number: string;
  title: string;
  description: string;
}

export const DIFFERENTIALS: DifferentialItem[] = [
  {
    number: '01',
    title: 'Entrega ágil',
    description:
      'Cronograma claro desde o primeiro dia para colocar seu site ou aplicativo no ar sem atrasos intermináveis.',
  },
  {
    number: '02',
    title: 'Preços acessíveis',
    description:
      'Excelente custo-benefício com escopo transparente e investimento justo para quem quer crescer com segurança.',
  },
  {
    number: '03',
    title: 'Design personalizado',
    description:
      'Nada de visual genérico: cada projeto é desenhado para valorizar sua marca e transmitir confiança ao seu cliente.',
  },
  {
    number: '04',
    title: 'Sites responsivos',
    description:
      'Funcionamento impecável no celular, tablet e computador — onde a maioria dos seus clientes pesquisa hoje.',
  },
  {
    number: '05',
    title: 'Atendimento direto',
    description:
      'Você fala diretamente comigo do orçamento à entrega final, com comunicação clara, rápida e sem intermediários.',
  },
];

export interface TestimonialItem {
  id: string;
  quote: string;
  clientName: string;
  role: string;
  company: string;
  outcome: string;
}

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 't1',
    quote:
      'Antes dependíamos apenas de indicações e redes sociais. Com o novo site criado pelo Paulo, passamos a receber pedidos diários pelo WhatsApp de empresas que nos encontram no Google.',
    clientName: 'Rafael Mendes',
    role: 'Sócio-Diretor',
    company: 'Mendes Engenharia & Obras',
    outcome: 'Novo site institucional · Entrega em 12 dias',
  },
  {
    id: 't2',
    quote:
      'Precisávamos de um aplicativo simples para nossos clientes acompanharem os atendimentos, sem pagar valores irreais de grandes agências. O Paulo entendeu a demanda rápido e entregou além do esperado.',
    clientName: 'Camila Ferreira',
    role: 'Fundadora',
    company: 'Clínica Vida Plena',
    outcome: 'Aplicativo de agendamentos · Atendimento direto',
  },
  {
    id: 't3',
    quote:
      'Meu site antigo travava no celular e eu não conseguia suporte. O Paulo assumiu a manutenção, reformulou a página inicial e hoje o carregamento é imediato. Excelente custo-benefício.',
    clientName: 'Henrique Almeida',
    role: 'Proprietário',
    company: 'Almeida Contabilidade Digital',
    outcome: 'Manutenção e otimização · +90% velocidade mobile',
  },
];

export const HERO_METRICS = [
  { value: '100%', label: 'Responsivo em qualquer tela' },
  { value: 'Direto', label: 'Atendimento pessoal sem robôs' },
  { value: 'Ágil', label: 'Prazos reais do briefing ao ar' },
  { value: 'Sob medida', label: 'Design exclusivo para sua marca' },
];

export const HERO_IMAGE = '/src/assets/images/hero_studio_showcase_1795037707145.jpg';
export const ABOUT_IMAGE = '/src/assets/images/about_paulo_studio_1795037709277.jpg';
